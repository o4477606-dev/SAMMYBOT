// Быстрая проверка: сервер стартует, отдаёт страницу и не работает без ключа API.
const { spawn } = require('child_process');
const path = require('path');
const PORT = 3999;
const env = { ...process.env, PORT: String(PORT) };
delete env.ANTHROPIC_API_KEY;
const srv = spawn(process.execPath, [path.join(__dirname, '..', 'server.js')], { env, stdio: ['ignore', 'pipe', 'inherit'] });
const fail = m => { console.error('FAIL:', m); srv.kill(); process.exit(1); };
srv.stdout.once('data', async () => {
  try {
    const base = 'http://127.0.0.1:' + PORT;
    let r = await fetch(base + '/');
    if (r.status !== 200 || !(await r.text()).includes('SAMMYBOT')) return fail('index');
    r = await fetch(base + '/manifest.webmanifest');
    if (r.status !== 200) return fail('manifest');
    r = await fetch(base + '/server.js');
    if (r.status !== 404) return fail('server.js must not be public');
    r = await fetch(base + '/api/recognize', { method: 'POST', body: '{}' });
    if (r.status !== 500) return fail('recognize without key');
    console.log('OK');
    srv.kill();
  } catch (e) { fail(e.message); }
});
